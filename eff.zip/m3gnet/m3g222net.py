
import time, os
from m3gnet.models import Relaxer
from pymatgen.core import Lattice, Structure
import numpy as np, torch 
import time
cpu_num = 4
log_file = 'time.log'
def run(cpu_num):
    os.environ ['OMP_NUM_THREADS'] = str(cpu_num)
    os.environ ['OPENBLAS_NUM_THREADS'] = str(cpu_num)
    os.environ ['MKL_NUM_THREADS'] = str(cpu_num)
    os.environ ['VECLIB_MAXIMUM_THREADS'] = str(cpu_num)
    os.environ ['NUMEXPR_NUM_THREADS'] = str(cpu_num)
    torch.set_num_threads(cpu_num)
    mo = Structure.from_file('./POSCAR')
    relaxer = Relaxer()
    t1 = time.time()
    relax_results = relaxer.relax(mo, verbose=True)
    t2 = time.time()
    f = open(log_file,'a')
    f.write('cpu_num:')
    f.write(str(cpu_num))
    f.write('    time:')
    f.write(str(t2-t1))
    f.write('s\n')
    f.close()
    
for cpu_num  in [1,2,4,8,16,32]:
    run(cpu_num)