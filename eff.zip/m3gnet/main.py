from __future__ import annotations
import warnings
warnings.filterwarnings('ignore')
from ase.md.velocitydistribution import MaxwellBoltzmannDistribution
from pymatgen.core import Lattice, Structure
from pymatgen.io.ase import AseAtomsAdaptor
import time, os, matgl
from matgl.ext.ase import PESCalculator, MolecularDynamics, Relaxer
import numpy as np, torch 
from ase.io import read, write, Trajectory as traj
from ase.build.tools import sort 
from ase.db import connect as conn 
from ase.atoms import Atoms
from ase.build import sort
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"  # 使CUDA设备不可见
class GenStructure:
    def __init__(self, aobj, n=-1):
        self.initobj = aobj 
        self.timestm = int(time.time()) if n < 0 else n

    def mutation(self):
        self.mutated = self.initobj.copy() 
        _rscalem     = np.eye(3)
        np.fill_diagonal(_rscalem, np.random.rand(3)*0.03 - 0.015 +1.0)
        _drctpos     = self.mutated.get_scaled_positions(wrap=True)
        _drctpos    += 0.1*np.random.random(_drctpos.shape)
        self.mutated.set_cell(self.mutated.cell*_rscalem)
        self.mutated.set_scaled_positions(_drctpos)
    
    def mc_change(self):
        mutated_symbols = self.mutated.get_chemical_symbols()
        unique_symbols = list(set(mutated_symbols))
        if len(unique_symbols) > 1:
            to_replace_index = np.random.randint(len(mutated_symbols))
            to_replace_with_symbol = np.random.choice([sym for sym in unique_symbols if sym != mutated_symbols[to_replace_index]])
            mutated_symbols[to_replace_index] = to_replace_with_symbol
            self.mutated.set_chemical_symbols(mutated_symbols)
        self.mutated = sort(self.mutated)

    def SetMDEngine(self):
        if self.timestm < 100:
            _intime  = int(time.time())%100
            _intime += self.timestm*100 
        else:
            _intime  = self.timestm
        np.random.seed(_intime)
        self.mutation()
        self.mc_change()
        self.trgtobj = self.mutated.copy()
        self.uninpes = matgl.load_model("/share/home/sutianhao/automlp/matgl-main/pretrained_models/M3GNet-MP-2021.2.8-PES")
        MaxwellBoltzmannDistribution(self.trgtobj, temperature_K=10)
        self.mdriver = Relaxer(self.trgtobj, potential=self.uninpes, timestep=0.05, temperature=300, logfile=f"md_trial-{self.timestm}.log",trajectory=f"md_trial-{self.timestm}.traj", ensemble="npt_nose_hoover")

    def runMD(self, n=1000):
        self.mdriver.run(n)
        _alltrajs    = read(f"md_trial-{self.timestm}.traj",":")
        self.intlver = _alltrajs[::200]
        _            = [i.wrap() for i in self.intlver]
        with conn(f"selected-{self.timestm}.db") as db:
            _ = [db.write(i,mpid=f"hfo2-{self.timestm}-{j}") for j,i in enumerate(self.intlver)]
def genini(n):
    cpu_num = 4
    os.environ ['OMP_NUM_THREADS'] = str(cpu_num)
    os.environ ['OPENBLAS_NUM_THREADS'] = str(cpu_num)
    os.environ ['MKL_NUM_THREADS'] = str(cpu_num)
    os.environ ['VECLIB_MAXIMUM_THREADS'] = str(cpu_num)
    os.environ ['NUMEXPR_NUM_THREADS'] = str(cpu_num)
    torch.set_num_threads(cpu_num)
    test = GenStructure(read("POSCAR"), n)
    test.SetMDEngine()
    test.runMD()
    return test.intlver

from multiprocessing import Pool 
with Pool(16) as p:
    _allimg = p.map(genini, range(1000))
allimg = [j for i in _allimg for j in i]
mol = allimg[0].get_chemical_formula()
atm = list(set(list(allimg[0].symbols)))
with conn("TaNbMoAlTi_allimgs.db") as db:
    _ = [db.write(a, mpid=f"{mol}-{n}") for n,a in enumerate(allimg)]
    _ = [db.write(Atoms(a, pbc=True, cell=20.0*np.eye(3), positions=np.zeros((1,3))), mpid=f"atom-{a}") for a in atm]
